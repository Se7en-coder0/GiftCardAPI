﻿namespace GiftCardAPI.DTOs.GiftCardsDTOs
{
    public class CreateGiftCardDto
    {
        public string Name { get; set; } = null!;
        public decimal Amount { get; set; }
    }
}
