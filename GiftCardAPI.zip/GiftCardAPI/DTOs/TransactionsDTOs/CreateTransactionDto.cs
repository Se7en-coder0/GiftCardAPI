﻿namespace GiftCardAPI.DTOs.TransactionsDTOs
{
    public class CreateTransactionDto
    {
        public int GiftCardId { get; set; }
    }
}
