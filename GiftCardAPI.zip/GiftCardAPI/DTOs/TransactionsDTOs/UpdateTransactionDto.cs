﻿namespace GiftCardAPI.DTOs.TransactionsDTOs
{
    public class UpdateTransactionDto
    {
        public int Id { get; set; }
        public bool Redeemed { get; set; }
    }
}
