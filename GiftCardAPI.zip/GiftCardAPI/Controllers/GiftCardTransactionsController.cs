﻿using AutoMapper;
using GiftCardAPI.DTOs.TransactionsDTOs;
using GiftCardAPI.Models;
using GiftCardAPI.Repositories.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace GiftCardAPI.Controllers
{
    [ApiController]
    [Route("api")]
    public class GiftCardTransactionsController : ControllerBase
    {
        private readonly IGiftCardTransactionRepository _transactionRepo;
        private readonly IUserRepository _userRepo;
        private readonly IMapper _mapper;

        public GiftCardTransactionsController(
            IGiftCardTransactionRepository transactionRepo,
            IUserRepository userRepo,
            IMapper mapper)
        {
            _transactionRepo = transactionRepo;
            _userRepo = userRepo;
            _mapper = mapper;
        }

        // GET: api/users/{userId}/transactions
        [HttpGet("users/{userId}/transactions")]
        public async Task<ActionResult<IEnumerable<GiftCardTransactionDto>>> GetTransactionsForUser(int userId)
        {
            if (!await _userRepo.ExistsAsync(userId))
                return NotFound();

            var transactions = await _transactionRepo.GetUserTransactionsAsync(userId);
            var dto = _mapper.Map<List<GiftCardTransactionDto>>(transactions);
            return Ok(dto);
        }

        [HttpPost("users/{userId}/transactions")]
        public async Task<ActionResult<GiftCardTransactionDto>> CreateTransaction(int userId, CreateTransactionDto dto)
        {
            if (!await _userRepo.ExistsAsync(userId))
                return NotFound();

            var transaction = _mapper.Map<GiftCardTransaction>(dto);
            transaction.UserId = userId;
            transaction.PurchasedAt = DateTime.UtcNow;
            transaction.Redeemed = false;

            await _transactionRepo.AddAsync(transaction);

            var fullTransaction = await _transactionRepo.GetByIdAsync(transaction.Id);

            var resultDto = _mapper.Map<GiftCardTransactionDto>(fullTransaction);
            return CreatedAtAction(nameof(GetTransactionsForUser), new { userId }, resultDto);
        }

        // PUT: api/transactions/{id}/redeem
        [HttpPut("transactions/{id}/redeem")]
        public async Task<IActionResult> RedeemTransaction(int id)
        {
            var transaction = await _transactionRepo.GetByIdAsync(id);
            if (transaction == null) return NotFound();

            transaction.Redeemed = true;
            await _transactionRepo.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/transactions/{id}
        [HttpDelete("transactions/{id}")]
        public IActionResult DeleteTransaction(int id)
        {
            return StatusCode(StatusCodes.Status501NotImplemented, new
            {
                message = "Deleting gift card transactions is not allowed."
            });
        }
    }
}
