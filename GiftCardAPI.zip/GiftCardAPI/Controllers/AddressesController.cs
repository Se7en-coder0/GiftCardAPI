﻿using AutoMapper;
using GiftCardAPI.DTOs.AddressesDTOs;
using GiftCardAPI.Models;
using GiftCardAPI.Repositories.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace GiftCardAPI.Controllers
{
    [ApiController]
    [Route("api")]
    public class AddressesController : ControllerBase
    {
        private readonly IAddressRepository _repository;
        private readonly IMapper _mapper;

        public AddressesController(IAddressRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        // GET: api/users/{userId}/addresses
        [HttpGet("users/{userId}/addresses")]
        public async Task<ActionResult<IEnumerable<AddressDto>>> GetAddressesForUser(int userId)
        {
            var addresses = await _repository.GetAddressesForUserAsync(userId);
            var addressDtos = _mapper.Map<List<AddressDto>>(addresses);
            return Ok(addressDtos);
        }

        // POST: api/users/{userId}/addresses
        [HttpPost("users/{userId}/addresses")]
        public async Task<ActionResult<AddressDto>> CreateAddress(int userId, CreateAddressDto dto)
        {
            var address = _mapper.Map<Address>(dto);
            address.UserId = userId;

            await _repository.AddAsync(address);
            await _repository.SaveChangesAsync();

            var addressDto = _mapper.Map<AddressDto>(address);
            return CreatedAtAction(nameof(GetAddressesForUser), new { userId }, addressDto);
        }

        // PUT: api/addresses/{id}
        [HttpPut("addresses/{id}")]
        public async Task<IActionResult> UpdateAddress(int id, UpdateAddressDto dto)
        {
            if (id != dto.Id) return BadRequest();

            var address = await _repository.GetByIdAsync(id);
            if (address == null) return NotFound();

            _mapper.Map(dto, address);
            await _repository.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/addresses/{id}
        [HttpDelete("addresses/{id}")]
        public async Task<IActionResult> DeleteAddress(int id)
        {
            var address = await _repository.GetByIdAsync(id);
            if (address == null) return NotFound();

            _repository.Delete(address);
            await _repository.SaveChangesAsync();

            return NoContent();
        }
    }
}
