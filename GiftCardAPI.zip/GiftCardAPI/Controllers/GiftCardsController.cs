﻿using GiftCardAPI.Services.Interfaces;
using GiftCardAPI.DTOs.GiftCardsDTOs;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;

namespace GiftCardAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class GiftCardsController : ControllerBase
    {
        private readonly IGiftCardService _giftCardService;
        private readonly IMapper _mapper;

        public GiftCardsController(IGiftCardService giftCardService, IMapper mapper)
        {
            _giftCardService = giftCardService;
            _mapper = mapper;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<GiftCardSimpleDto>>> GetAllGiftCards()
        {
            var giftCards = await _giftCardService.GetAllGiftCardsAsync();
            var resultDto = _mapper.Map<List<GiftCardSimpleDto>>(giftCards);
            return Ok(resultDto);
        }

        [HttpPost]
        public async Task<ActionResult<GiftCardSimpleDto>> CreateGiftCard(CreateGiftCardDto giftCardDto)
        {
            var giftCard = await _giftCardService.CreateGiftCardAsync(giftCardDto);
            var resultDto = _mapper.Map<GiftCardSimpleDto>(giftCard);
            return CreatedAtAction(nameof(GetAllGiftCards), new { id = giftCard.Id }, resultDto);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<GiftCardSimpleDto>> GetGiftCardById(int id)
        {
            var giftCard = await _giftCardService.GetGiftCardByIdAsync(id);
            if (giftCard == null)
                return NotFound();

            var resultDto = _mapper.Map<GiftCardSimpleDto>(giftCard);
            return Ok(resultDto);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateGiftCard(int id, CreateGiftCardDto giftCardDto)
        {
            await _giftCardService.UpdateGiftCardAsync(id, giftCardDto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteGiftCard(int id)
        {
            await _giftCardService.DeleteGiftCardAsync(id);
            return NoContent();
        }
    }
}
