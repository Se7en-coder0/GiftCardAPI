﻿using AutoMapper;
using GiftCardAPI.Data;
using GiftCardAPI.DTOs.UsersDTOs;
using GiftCardAPI.Models;
using GiftCardAPI.Repositories.Interfaces;
using GiftCardAPI.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace GiftCardAPI.Services.Implementations
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;
        private readonly IMapper _mapper;
        private readonly ILogger<UserService> _logger;

        public UserService(IUserRepository userRepository, IMapper mapper, ILogger<UserService> logger)
        {
            _userRepository = userRepository;
            _mapper = mapper;
            _logger = logger;
        }

        public async Task<User> CreateUserAsync(CreateUserDto userDto)
        {
            var user = _mapper.Map<User>(userDto);
            _userRepository.AddAsync(user);
            await _userRepository.SaveChangesAsync();

            _logger.LogInformation("User created with ID {UserId}", user.Id);
            return user;
        }

        public async Task<User> GetUserByIdAsync(int id)
        {
            var user = await _userRepository.GetByIdAsync(id);
            if (user == null)
            {
                _logger.LogWarning("User with ID {UserId} not found", id);
                return null!;
            }

            return user;
        }

        public async Task<IEnumerable<User>> GetAllUsersAsync()
        {
            return await _userRepository.GetAllAsync();
        }

        public async Task UpdateUserAsync(int id, UpdateUserDto userDto)
        {
            var user = await _userRepository.GetByIdAsync(id);
            if (user == null)
            {
                _logger.LogWarning("User with ID {UserId} not found", id);
                return;
            }

            _mapper.Map(userDto, user);
            await _userRepository.SaveChangesAsync();

            _logger.LogInformation("User with ID {UserId} updated", id);
        }

        public async Task DeleteUserAsync(int id)
        {
            var user = await _userRepository.GetByIdAsync(id);
            if (user == null)
            {
                _logger.LogWarning("User with ID {UserId} not found", id);
                return;
            }

            await _userRepository.DeleteAsync(user);

            _logger.LogInformation("User with ID {UserId} deleted", id);
        }
    }
}
