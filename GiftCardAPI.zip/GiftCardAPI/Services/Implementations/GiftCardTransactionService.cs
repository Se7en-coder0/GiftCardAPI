﻿using AutoMapper;
using GiftCardAPI.DTOs.TransactionsDTOs;
using GiftCardAPI.Models;
using GiftCardAPI.Repositories.Interfaces;
using GiftCardAPI.Services.Interfaces;
using Microsoft.Extensions.Logging;

namespace GiftCardAPI.Services.Implementations
{
    public class GiftCardTransactionService : IGiftCardTransactionService
    {
        private readonly IGiftCardTransactionRepository _transactionRepository;
        private readonly IUserRepository _userRepository;
        private readonly IGiftCardRepository _giftCardRepository;
        private readonly IMapper _mapper;
        private readonly ILogger<GiftCardTransactionService> _logger;

        public GiftCardTransactionService(
            IGiftCardTransactionRepository transactionRepository,
            IUserRepository userRepository,
            IGiftCardRepository giftCardRepository,
            IMapper mapper,
            ILogger<GiftCardTransactionService> logger)
        {
            _transactionRepository = transactionRepository;
            _userRepository = userRepository;
            _giftCardRepository = giftCardRepository;
            _mapper = mapper;
            _logger = logger;
        }

        public async Task<GiftCardTransaction> CreateTransactionAsync(int userId, int giftCardId, GiftCardTransactionDto transactionDto)
        {
            var user = await _userRepository.GetByIdAsync(userId);
            if (user == null)
            {
                _logger.LogWarning("User with ID {UserId} not found", userId);
                throw new ArgumentException("User not found");
            }

            var giftCard = await _giftCardRepository.GetByIdAsync(giftCardId);
            if (giftCard == null)
            {
                _logger.LogWarning("Gift card with ID {GiftCardId} not found", giftCardId);
                throw new ArgumentException("Gift card not found");
            }

            var transaction = _mapper.Map<GiftCardTransaction>(transactionDto);
            transaction.UserId = userId;
            transaction.GiftCardId = giftCardId;

            await _transactionRepository.AddAsync(transaction);
            await _transactionRepository.SaveChangesAsync();

            _logger.LogInformation("Transaction created with ID {TransactionId}", transaction.Id);
            return transaction;
        }

        public async Task<IEnumerable<GiftCardTransaction>> GetTransactionsForUserAsync(int userId)
        {
            // No need to check if the user exists here, just fetch transactions
            var transactions = await _transactionRepository.GetTransactionsForUserAsync(userId);

            if (transactions == null || !transactions.Any())
            {
                _logger.LogWarning("No transactions found for user with ID {UserId}", userId);
            }

            return transactions;
        }

        public async Task RedeemTransactionAsync(int transactionId)
        {
            var transaction = await _transactionRepository.GetByIdAsync(transactionId);
            if (transaction == null)
            {
                _logger.LogWarning("Transaction with ID {TransactionId} not found", transactionId);
                throw new ArgumentException("Transaction not found");
            }

            if (transaction.Redeemed)
            {
                _logger.LogWarning("Transaction with ID {TransactionId} is already redeemed", transactionId);
                throw new InvalidOperationException("Transaction already redeemed");
            }

            transaction.Redeemed = true;
            await _transactionRepository.SaveChangesAsync();

            _logger.LogInformation("Transaction with ID {TransactionId} marked as redeemed", transactionId);
        }
    }
}
